
<?php
session_start();
require_once "db.php";

// CSRF protection
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$message = "";

// DELETE EMPLOYEE
if (isset($_POST['delete'])) {

    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        die("Invalid request");
    }

    $id = (int)$_POST['id'];

    $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
    $stmt->execute([$id]);

    $message = "Employee deleted successfully!";
}

// ADD / UPDATE EMPLOYEE
if (isset($_POST['save'])) {

    if (!hash_equals($_SESSION['csrf'], $_POST['csrf'] ?? '')) {
        die("Invalid request");
    }

    $id = (int)($_POST['id'] ?? 0);

    $name = trim($_POST['employee_name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');

    $salary = (float)($_POST['salary'] ?? 0);
    $esi = (float)($_POST['esi'] ?? 0);
    $pf = (float)($_POST['pf'] ?? 0);
    $hra = (float)($_POST['hra'] ?? 0);

    if ($name === '' || $salary < 0 || $esi < 0 ||
        $pf < 0 || $hra < 0) {

        $message = "Please enter valid employee details.";

    } else {

        if ($id > 0) {

            $sql = "UPDATE employees SET
                    employee_name=?,
                    address=?,
                    mobile=?,
                    salary=?,
                    esi=?,
                    pf=?,
                    hra=?
                    WHERE id=?";

            $stmt = $conn->prepare($sql);

            $stmt->execute([
                $name, $address, $mobile,
                $salary, $esi, $pf, $hra, $id
            ]);

            $message = "Employee updated successfully!";

        } else {

            $sql = "INSERT INTO employees
                    (employee_name,address,mobile,salary,esi,pf,hra)
                    VALUES (?,?,?,?,?,?,?)";

            $stmt = $conn->prepare($sql);

            $stmt->execute([
                $name, $address, $mobile,
                $salary, $esi, $pf, $hra
            ]);

            $message = "Employee added successfully!";
        }
    }
}

// EDIT EMPLOYEE
$editEmployee = null;

if (isset($_GET['edit'])) {

    $id = (int)$_GET['edit'];

    $stmt = $conn->prepare("SELECT * FROM employees WHERE id=?");
    $stmt->execute([$id]);

    $editEmployee = $stmt->fetch(PDO::FETCH_ASSOC);
}

// SEARCH EMPLOYEES
$search = trim($_GET['search'] ?? '');

if ($search !== '') {

    $stmt = $conn->prepare(
        "SELECT * FROM employees
         WHERE employee_name LIKE ?
         OR mobile LIKE ?
         ORDER BY id DESC"
    );

    $stmt->execute(["%$search%", "%$search%"]);

} else {

    $stmt = $conn->query(
        "SELECT * FROM employees ORDER BY id DESC"
    );
}

$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>

    <title>Employee Management System</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

</head>

<body class="bg-light">

<div class="container py-4">

    <h2 class="text-center text-primary mb-4">
        Employee Management System
    </h2>

    <?php if ($message): ?>

        <div class="alert alert-info">
            <?= e($message) ?>
        </div>

    <?php endif; ?>

    <!-- EMPLOYEE FORM -->

    <div class="card shadow mb-4">

        <div class="card-header bg-primary text-white">

            <?= $editEmployee ? "Edit Employee" : "Add New Employee" ?>

        </div>

        <div class="card-body">

            <form method="POST">

                <input type="hidden" name="csrf"
                       value="<?= e($_SESSION['csrf']) ?>">

                <input type="hidden" name="id"
                       value="<?= e($editEmployee['id'] ?? '') ?>">

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label">Employee Name</label>

                        <input type="text"
                               name="employee_name"
                               class="form-control"
                               required
                               value="<?= e($editEmployee['employee_name'] ?? '') ?>">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">Mobile Number</label>

                        <input type="text"
                               name="mobile"
                               class="form-control"
                               maxlength="15"
                               value="<?= e($editEmployee['mobile'] ?? '') ?>">

                    </div>

                    <div class="col-md-12 mb-3">

                        <label class="form-label">Address</label>

                        <textarea name="address"
                                  class="form-control"
                                  rows="2"><?= e($editEmployee['address'] ?? '') ?></textarea>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">Salary</label>

                        <input type="number"
                               step="0.01"
                               min="0"
                               name="salary"
                               class="form-control"
                               value="<?= e($editEmployee['salary'] ?? '0') ?>">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">ESI</label>

                        <input type="number"
                               step="0.01"
                               min="0"
                               name="esi"
                               class="form-control"
                               value="<?= e($editEmployee['esi'] ?? '0') ?>">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">PF</label>

                        <input type="number"
                               step="0.01"
                               min="0"
                               name="pf"
                               class="form-control"
                               value="<?= e($editEmployee['pf'] ?? '0') ?>">

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">HRA</label>

                        <input type="number"
                               step="0.01"
                               min="0"
                               name="hra"
                               class="form-control"
                               value="<?= e($editEmployee['hra'] ?? '0') ?>">

                    </div>

                </div>

                <button type="submit"
                        name="save"
                        class="btn btn-success">

                    <?= $editEmployee ? "Update Employee" : "Save Employee" ?>

                </button>

                <?php if ($editEmployee): ?>

                    <a href="index.php" class="btn btn-secondary">
                        Cancel
                    </a>

                <?php endif; ?>

            </form>

        </div>

    </div>

    <!-- EMPLOYEE LIST -->

    <div class="card shadow">

        <div class="card-header bg-dark text-white">

            Employee Details

        </div>

        <div class="card-body">

            <form method="GET" class="mb-3">

                <div class="input-group">

                    <input type="text"
                           name="search"
                           class="form-control"
                           placeholder="Search employee name or mobile"
                           value="<?= e($search) ?>">

                    <button class="btn btn-primary">
                        Search
                    </button>

                    <a href="index.php" class="btn btn-secondary">
                        Reset
                    </a>

                </div>

            </form>

            <div class="table-responsive">

                <table class="table table-bordered table-striped">

                    <thead class="table-primary">

                        <tr>
                            <th>ID</th>
                            <th>Employee Name</th>
                            <th>Address</th>
                            <th>Mobile</th>
                            <th>Salary</th>
                            <th>ESI</th>
                            <th>PF</th>
                            <th>HRA</th>
                            <th>Action</th>
                        </tr>

                    </thead>

                    <tbody>

                    <?php if (count($employees) > 0): ?>

                        <?php foreach ($employees as $row): ?>

                            <tr>

                                <td><?= e($row['id']) ?></td>

                                <td><?= e($row['employee_name']) ?></td>

                                <td><?= e($row['address']) ?></td>

                                <td><?= e($row['mobile']) ?></td>

                                <td><?= number_format((float)$row['salary'], 2) ?></td>

                                <td><?= number_format((float)$row['esi'], 2) ?></td>

                                <td><?= number_format((float)$row['pf'], 2) ?></td>

                                <td><?= number_format((float)$row['hra'], 2) ?></td>

                                <td>

                                    <a href="index.php?edit=<?= e($row['id']) ?>"
                                       class="btn btn-warning btn-sm">
                                        Edit
                                    </a>

                                    <form method="POST"
                                          class="d-inline"
                                          onsubmit="return confirm('Delete this employee?');">

                                        <input type="hidden"
                                               name="csrf"
                                               value="<?= e($_SESSION['csrf']) ?>">

                                        <input type="hidden"
                                               name="id"
                                               value="<?= e($row['id']) ?>">

                                        <button type="submit"
                                                name="delete"
                                                class="btn btn-danger btn-sm">
                                            Delete
                                        </button>

                                    </form>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="9" class="text-center">
                                No Employee Records Found
                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <p class="text-muted">
                Total Employees: <?= count($employees) ?>
            </p>

        </div>

    </div>

</div>

</body>
</html>
