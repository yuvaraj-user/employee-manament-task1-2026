
const modal = new bootstrap.Modal(
    document.getElementById('employeeModal')
);

function money(value) {
    return Number(value).toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR'
    });
}

// Salary calculation
function calculateSalary() {

    const basic = Number(document.getElementById('basic_salary').value) || 0;
    const hra = Number(document.getElementById('hra').value) || 0;
    const esi = Number(document.getElementById('esi').value) || 0;
    const pf = Number(document.getElementById('pf').value) || 0;

    const gross = basic + hra;
    const deductions = esi + pf;
    const net = gross - deductions;

    document.getElementById('grossPreview').textContent = money(gross);
    document.getElementById('deductionPreview').textContent = money(deductions);
    document.getElementById('netPreview').textContent = money(net);
}

document.querySelectorAll('.salary-input').forEach(input => {
    input.addEventListener('input', calculateSalary);
});

// Add employee
function openAddModal() {

    document.getElementById('employeeForm').reset();
    document.getElementById('employee_id').value = '';

    document.getElementById('modalTitle').textContent = 'Add Employee';

    calculateSalary();
    modal.show();
}

// Edit employee
async function editEmployee(id) {

    const response = await fetch(
        `ajax/get_employee.php?id=${encodeURIComponent(id)}`
    );

    const emp = await response.json();

    if (!response.ok) {
        alert(emp.message || 'Unable to load employee');
        return;
    }

    document.getElementById('employee_id').value = emp.id;
    document.getElementById('employee_name').value = emp.employee_name;
    document.getElementById('mobile').value = emp.mobile || '';
    document.getElementById('address').value = emp.address || '';

    document.getElementById('basic_salary').value = emp.basic_salary;
    document.getElementById('hra').value = emp.hra;
    document.getElementById('esi').value = emp.esi;
    document.getElementById('pf').value = emp.pf;

    document.getElementById('modalTitle').textContent = 'Edit Employee';

    calculateSalary();
    modal.show();
}

// Save employee
document.getElementById('employeeForm').addEventListener('submit', async function(e) {

    e.preventDefault();

    const formData = new FormData(this);

    try {
        const response = await fetch('ajax/save_employee.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (!response.ok || result.status !== 'success') {
            throw new Error(result.message || 'Save failed');
        }

        alert(result.message);
        location.reload();

    } catch (error) {
        alert(error.message);
    }
});

// Delete employee
async function deleteEmployee(id) {

    if (!confirm('Are you sure you want to delete this employee?')) {
        return;
    }

    const formData = new FormData();
    formData.append('id', id);

    try {
        const response = await fetch('ajax/delete_employee.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (!response.ok || result.status !== 'success') {
            throw new Error(result.message || 'Delete failed');
        }

        alert(result.message);
        location.reload();

    } catch (error) {
        alert(error.message);
    }
}

// Live employee search
document.getElementById('searchInput').addEventListener('input', async function() {

    const keyword = this.value.toLowerCase();

    document.querySelectorAll('#employeeTable tr').forEach(row => {

        row.style.display = row.textContent.toLowerCase().includes(keyword)
            ? ''
            : 'none';

    });

});
