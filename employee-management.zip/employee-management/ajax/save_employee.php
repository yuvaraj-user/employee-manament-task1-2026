
<?php
require_once '../config/database.php';

header('Content-Type: application/json');

try {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request');
    }

    $id = (int)($_POST['id'] ?? 0);

    $name = trim($_POST['employee_name'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $address = trim($_POST['address'] ?? '');

    $basic = filter_var($_POST['basic_salary'] ?? null, FILTER_VALIDATE_FLOAT);
    $hra = filter_var($_POST['hra'] ?? null, FILTER_VALIDATE_FLOAT);
    $esi = filter_var($_POST['esi'] ?? null, FILTER_VALIDATE_FLOAT);
    $pf = filter_var($_POST['pf'] ?? null, FILTER_VALIDATE_FLOAT);

    if ($name === '' || $basic === false || $basic < 0 ||
        $hra === false || $hra < 0 ||
        $esi === false || $esi < 0 ||
        $pf === false || $pf < 0) {
        throw new Exception('Please enter valid employee and salary details');
    }

    if (strlen($name) > 150 || strlen($mobile) > 15) {
        throw new Exception('Invalid field length');
    }

    $gross = $basic + $hra;
    $net = $gross - $esi - $pf;

    if ($net < 0) {
        throw new Exception('Deductions cannot exceed gross salary');
    }

    if ($id > 0) {

        $sql = "UPDATE employees SET
                employee_name = ?,
                mobile = ?,
                address = ?,
                basic_salary = ?,
                salary = ?,
                hra = ?,
                esi = ?,
                pf = ?,
                gross_salary = ?,
                net_salary = ?
                WHERE id = ?";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            $name, $mobile, $address,
            $basic, $basic, $hra, $esi, $pf,
            $gross, $net, $id
        ]);

        echo json_encode([
            'status' => 'success',
            'message' => 'Employee updated successfully'
        ]);

    } else {

        $sql = "INSERT INTO employees
                (employee_name, mobile, address,
                 basic_salary, salary, hra, esi, pf,
                 gross_salary, net_salary)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            $name, $mobile, $address,
            $basic, $basic, $hra, $esi, $pf,
            $gross, $net
        ]);

        echo json_encode([
            'status' => 'success',
            'message' => 'Employee added successfully'
        ]);
    }

} catch (Throwable $e) {

    http_response_code(400);

    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
