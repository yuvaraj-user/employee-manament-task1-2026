
<?php
require_once '../config/database.php';

header('Content-Type: application/json');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid ID']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$id]);

$employee = $stmt->fetch();

if (!$employee) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Employee not found']);
    exit;
}

echo json_encode($employee);
