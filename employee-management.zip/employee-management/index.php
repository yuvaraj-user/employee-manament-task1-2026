
<?php
require_once 'config/database.php';

$totalEmployees = $pdo->query(
    "SELECT COUNT(*) FROM employees"
)->fetchColumn();

$totalBasic = $pdo->query(
    "SELECT COALESCE(SUM(basic_salary),0) FROM employees"
)->fetchColumn();

$totalPayroll = $pdo->query(
    "SELECT COALESCE(SUM(net_salary),0) FROM employees"
)->fetchColumn();

$employees = $pdo->query(
    "SELECT * FROM employees ORDER BY id DESC"
)->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Employee Management Portal</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="sidebar">
    <h4><i class="bi bi-people-fill"></i> Employee </h4>

    <a class="active" href="#">
        <i class="bi bi-grid"></i> Dashboard
    </a>

    <!-- <a href="#employeeSection">
        <i class="bi bi-people"></i> Employees
    </a>

    <a href="#employeeSection">
        <i class="bi bi-wallet2"></i> Payroll
    </a> -->
</div>

<div class="main-content">

    <div class="topbar">
        <div>
            <h3>Employee Dashboard</h3>
            <p>Manage your employees and payroll</p>
        </div>

        <button class="btn btn-primary" onclick="openAddModal()">
            <i class="bi bi-plus-lg"></i> Add Employee
        </button>
    </div>

    <div class="row g-4 mb-4">

        <div class="col-md-4">
            <div class="stat-card">
                <i class="bi bi-people"></i>
                <p>Total Employees</p>
                <h2><?= (int)$totalEmployees ?></h2>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <i class="bi bi-cash-stack"></i>
                <p>Total Basic Salary</p>
                <h2>₹<?= number_format((float)$totalBasic, 2) ?></h2>
            </div>
        </div>

        <div class="col-md-4">
            <div class="stat-card">
                <i class="bi bi-wallet2"></i>
                <p>Monthly Net Payroll</p>
                <h2>₹<?= number_format((float)$totalPayroll, 2) ?></h2>
            </div>
        </div>

    </div>

    <div class="employee-card" id="employeeSection">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h5>Employee List</h5>

            <input type="text"
                   id="searchInput"
                   class="form-control search-box"
                   placeholder="Search employees...">
        </div>

        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Employee</th>
                        <th>Mobile</th>
                        <th>Basic Salary</th>
                        <th>Gross Salary</th>
                        <th>Net Salary</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody id="employeeTable">

                <?php foreach ($employees as $emp): ?>

                    <tr>
                        <td>EMP<?= str_pad($emp['id'], 3, '0', STR_PAD_LEFT) ?></td>

                        <td>
                            <strong>
                                <?= htmlspecialchars($emp['employee_name']) ?>
                            </strong>
                        </td>

                        <td><?= htmlspecialchars($emp['mobile'] ?? '') ?></td>

                        <td>₹<?= number_format((float)$emp['basic_salary'], 2) ?></td>

                        <td>₹<?= number_format((float)$emp['gross_salary'], 2) ?></td>

                        <td class="text-success fw-bold">
                            ₹<?= number_format((float)$emp['net_salary'], 2) ?>
                        </td>

                        <td>
                            <button class="btn btn-sm btn-light"
                                onclick="editEmployee(<?= (int)$emp['id'] ?>)">
                                <i class="bi bi-pencil"></i>
                            </button>

                            <button class="btn btn-sm btn-light text-danger"
                                onclick="deleteEmployee(<?= (int)$emp['id'] ?>)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>

                <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- ADD / EDIT MODAL -->

<div class="modal fade" id="employeeModal" tabindex="-1">
<div class="modal-dialog modal-lg modal-dialog-centered">
<div class="modal-content">

<form id="employeeForm">

<div class="modal-header">
    <h5 class="modal-title" id="modalTitle">Add Employee</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">

<input type="hidden" name="id" id="employee_id">

<div class="row g-3">

    <div class="col-md-6">
        <label class="form-label">Employee Name</label>
        <input type="text" name="employee_name" id="employee_name"
               class="form-control" required maxlength="150">
    </div>

    <div class="col-md-6">
        <label class="form-label">Mobile</label>
        <input type="text" name="mobile" id="mobile"
               class="form-control" maxlength="15">
    </div>

    <div class="col-12">
        <label class="form-label">Address</label>
        <textarea name="address" id="address"
                  class="form-control"></textarea>
    </div>

    <div class="col-md-6">
        <label class="form-label">Basic Salary</label>
        <input type="number" step="0.01" min="0"
               name="basic_salary" id="basic_salary"
               class="form-control salary-input" value="0" required>
    </div>

    <div class="col-md-6">
        <label class="form-label">HRA</label>
        <input type="number" step="0.01" min="0"
               name="hra" id="hra"
               class="form-control salary-input" value="0">
    </div>

    <div class="col-md-6">
        <label class="form-label">ESI Deduction</label>
        <input type="number" step="0.01" min="0"
               name="esi" id="esi"
               class="form-control salary-input" value="0">
    </div>

    <div class="col-md-6">
        <label class="form-label">PF Deduction</label>
        <input type="number" step="0.01" min="0"
               name="pf" id="pf"
               class="form-control salary-input" value="0">
    </div>

</div>

<hr>

<div class="salary-preview">
    <div class="d-flex justify-content-between">
        <span>Gross Salary</span>
        <strong id="grossPreview">₹0.00</strong>
    </div>

    <div class="d-flex justify-content-between mt-2">
        <span>Total Deductions</span>
        <strong id="deductionPreview">₹0.00</strong>
    </div>

    <div class="d-flex justify-content-between mt-3">
        <h5>Net Salary</h5>
        <h5 class="text-success" id="netPreview">₹0.00</h5>
    </div>
</div>

</div>

<div class="modal-footer">
    <button type="button" class="btn btn-light" data-bs-dismiss="modal">
        Cancel
    </button>

    <button type="submit" class="btn btn-primary">
        Save Employee
    </button>
</div>

</form>

</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>

</body>
</html>
